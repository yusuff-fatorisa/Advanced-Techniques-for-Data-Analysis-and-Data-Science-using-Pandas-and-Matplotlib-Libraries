### Hello, welcome to another lesson where you'll learn more about the vast range of tools available in Python, Numpy Pandas, Matplotlib e.t.c for use in Data Science Toolbox.

### This is me sharing my journey from scratch . And hoping this will encourage you to keep doing it, even if it means doing it poorly, till you get better and gain mastery.

### I'm just so excited about my discovery and the vast possibilities on this career path using Python and its libraries.

### I'm sure if you follow the lessons and the previous ones, the vibes will definitely spread to you.

# Let's Get Started !!!

### The first step is to import the required libraries that you'll be working with which includes Numpy, Pandas and Matplotlib. Remember to include "%matplotlib inline" so that your plots can be displayed immediately.

### The dataset you'll be dealing with is a Sample Sales Data which can be found online. import the data and read it


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
dataset = pd.read_excel("Sample-sales-data-excel.xlsx")
dataset.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Row ID</th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>...</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>9984</td>
      <td>9985</td>
      <td>CA-2015-100251</td>
      <td>2015-05-17</td>
      <td>2015-05-23</td>
      <td>Standard Class</td>
      <td>DV-13465</td>
      <td>Dianna Vittorini</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Long Beach</td>
      <td>...</td>
      <td>11561</td>
      <td>East</td>
      <td>OFF-LA-10003766</td>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>Self-Adhesive Removable Labels</td>
      <td>31.500</td>
      <td>10</td>
      <td>0.0</td>
      <td>15.1200</td>
    </tr>
    <tr>
      <td>9985</td>
      <td>9986</td>
      <td>CA-2015-100251</td>
      <td>2015-05-17</td>
      <td>2015-05-23</td>
      <td>Standard Class</td>
      <td>DV-13465</td>
      <td>Dianna Vittorini</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Long Beach</td>
      <td>...</td>
      <td>11561</td>
      <td>East</td>
      <td>OFF-SU-10000898</td>
      <td>Office Supplies</td>
      <td>Supplies</td>
      <td>Acme Hot Forged Carbon Steel Scissors with Nic...</td>
      <td>55.600</td>
      <td>4</td>
      <td>0.0</td>
      <td>16.1240</td>
    </tr>
    <tr>
      <td>9986</td>
      <td>9987</td>
      <td>CA-2016-125794</td>
      <td>2016-09-29</td>
      <td>2016-10-03</td>
      <td>Standard Class</td>
      <td>ML-17410</td>
      <td>Maris LaWare</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>...</td>
      <td>90008</td>
      <td>West</td>
      <td>TEC-AC-10003399</td>
      <td>Technology</td>
      <td>Accessories</td>
      <td>Memorex Mini Travel Drive 64 GB USB 2.0 Flash ...</td>
      <td>36.240</td>
      <td>1</td>
      <td>0.0</td>
      <td>15.2208</td>
    </tr>
    <tr>
      <td>9987</td>
      <td>9988</td>
      <td>CA-2017-163629</td>
      <td>2017-11-17</td>
      <td>2017-11-21</td>
      <td>Standard Class</td>
      <td>RA-19885</td>
      <td>Ruben Ausman</td>
      <td>Corporate</td>
      <td>United States</td>
      <td>Athens</td>
      <td>...</td>
      <td>30605</td>
      <td>South</td>
      <td>TEC-AC-10001539</td>
      <td>Technology</td>
      <td>Accessories</td>
      <td>Logitech G430 Surround Sound Gaming Headset wi...</td>
      <td>79.990</td>
      <td>1</td>
      <td>0.0</td>
      <td>28.7964</td>
    </tr>
    <tr>
      <td>9988</td>
      <td>9989</td>
      <td>CA-2017-163629</td>
      <td>2017-11-17</td>
      <td>2017-11-21</td>
      <td>Standard Class</td>
      <td>RA-19885</td>
      <td>Ruben Ausman</td>
      <td>Corporate</td>
      <td>United States</td>
      <td>Athens</td>
      <td>...</td>
      <td>30605</td>
      <td>South</td>
      <td>TEC-PH-10004006</td>
      <td>Technology</td>
      <td>Phones</td>
      <td>Panasonic KX - TS880B Telephone</td>
      <td>206.100</td>
      <td>5</td>
      <td>0.0</td>
      <td>55.6470</td>
    </tr>
    <tr>
      <td>9989</td>
      <td>9990</td>
      <td>CA-2014-110422</td>
      <td>2014-01-21</td>
      <td>2014-01-23</td>
      <td>Second Class</td>
      <td>TB-21400</td>
      <td>Tom Boeckenhauer</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Miami</td>
      <td>...</td>
      <td>33180</td>
      <td>South</td>
      <td>FUR-FU-10001889</td>
      <td>Furniture</td>
      <td>Furnishings</td>
      <td>Ultra Door Pull Handle</td>
      <td>25.248</td>
      <td>3</td>
      <td>0.2</td>
      <td>4.1028</td>
    </tr>
    <tr>
      <td>9990</td>
      <td>9991</td>
      <td>CA-2017-121258</td>
      <td>2017-02-26</td>
      <td>2017-03-03</td>
      <td>Standard Class</td>
      <td>DB-13060</td>
      <td>Dave Brooks</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Costa Mesa</td>
      <td>...</td>
      <td>92627</td>
      <td>West</td>
      <td>FUR-FU-10000747</td>
      <td>Furniture</td>
      <td>Furnishings</td>
      <td>Tenex B1-RE Series Chair Mats for Low Pile Car...</td>
      <td>91.960</td>
      <td>2</td>
      <td>0.0</td>
      <td>15.6332</td>
    </tr>
    <tr>
      <td>9991</td>
      <td>9992</td>
      <td>CA-2017-121258</td>
      <td>2017-02-26</td>
      <td>2017-03-03</td>
      <td>Standard Class</td>
      <td>DB-13060</td>
      <td>Dave Brooks</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Costa Mesa</td>
      <td>...</td>
      <td>92627</td>
      <td>West</td>
      <td>TEC-PH-10003645</td>
      <td>Technology</td>
      <td>Phones</td>
      <td>Aastra 57i VoIP phone</td>
      <td>258.576</td>
      <td>2</td>
      <td>0.2</td>
      <td>19.3932</td>
    </tr>
    <tr>
      <td>9992</td>
      <td>9993</td>
      <td>CA-2017-121258</td>
      <td>2017-02-26</td>
      <td>2017-03-03</td>
      <td>Standard Class</td>
      <td>DB-13060</td>
      <td>Dave Brooks</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Costa Mesa</td>
      <td>...</td>
      <td>92627</td>
      <td>West</td>
      <td>OFF-PA-10004041</td>
      <td>Office Supplies</td>
      <td>Paper</td>
      <td>It's Hot Message Books with Stickers, 2 3/4" x 5"</td>
      <td>29.600</td>
      <td>4</td>
      <td>0.0</td>
      <td>13.3200</td>
    </tr>
    <tr>
      <td>9993</td>
      <td>9994</td>
      <td>CA-2017-119914</td>
      <td>2017-05-04</td>
      <td>2017-05-09</td>
      <td>Second Class</td>
      <td>CC-12220</td>
      <td>Chris Cortes</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Westminster</td>
      <td>...</td>
      <td>92683</td>
      <td>West</td>
      <td>OFF-AP-10002684</td>
      <td>Office Supplies</td>
      <td>Appliances</td>
      <td>Acco 7-Outlet Masterpiece Power Center, Wihtou...</td>
      <td>243.160</td>
      <td>2</td>
      <td>0.0</td>
      <td>72.9480</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 21 columns</p>
</div>



### By default, Pandas assigns a numerical index to the dataframe.  And the dataset has a column named "ROW ID".

### Intuitively, that should be the row index so i made that the row index and deleted the row.

#### Note that the same task can be achieved using "set_index()"


```python
dataset.index = dataset["Row ID"]
dataset.drop(['Row ID'], axis = "columns", inplace = True)
dataset.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 9994 entries, 1 to 9994
    Data columns (total 20 columns):
    Order ID         9994 non-null object
    Order Date       9994 non-null datetime64[ns]
    Ship Date        9994 non-null datetime64[ns]
    Ship Mode        9994 non-null object
    Customer ID      9994 non-null object
    Customer Name    9994 non-null object
    Segment          9994 non-null object
    Country          9994 non-null object
    City             9994 non-null object
    State            9994 non-null object
    Postal Code      9994 non-null int64
    Region           9994 non-null object
    Product ID       9994 non-null object
    Category         9994 non-null object
    Sub-Category     9994 non-null object
    Product Name     9994 non-null object
    Sales            9994 non-null float64
    Quantity         9994 non-null int64
    Discount         9994 non-null float64
    Profit           9994 non-null float64
    dtypes: datetime64[ns](2), float64(3), int64(2), object(13)
    memory usage: 1.1+ MB


### After the data has been loaded and read, you should familiarize yourself with various attributes of the dataset


```python
dataset.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Postal Code</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>count</td>
      <td>9994.000000</td>
      <td>9994.000000</td>
      <td>9994.000000</td>
      <td>9994.000000</td>
      <td>9994.000000</td>
    </tr>
    <tr>
      <td>mean</td>
      <td>55190.379428</td>
      <td>229.858001</td>
      <td>3.789574</td>
      <td>0.156203</td>
      <td>28.656896</td>
    </tr>
    <tr>
      <td>std</td>
      <td>32063.693350</td>
      <td>623.245101</td>
      <td>2.225110</td>
      <td>0.206452</td>
      <td>234.260108</td>
    </tr>
    <tr>
      <td>min</td>
      <td>1040.000000</td>
      <td>0.444000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>-6599.978000</td>
    </tr>
    <tr>
      <td>25%</td>
      <td>23223.000000</td>
      <td>17.280000</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>1.728750</td>
    </tr>
    <tr>
      <td>50%</td>
      <td>56430.500000</td>
      <td>54.490000</td>
      <td>3.000000</td>
      <td>0.200000</td>
      <td>8.666500</td>
    </tr>
    <tr>
      <td>75%</td>
      <td>90008.000000</td>
      <td>209.940000</td>
      <td>5.000000</td>
      <td>0.200000</td>
      <td>29.364000</td>
    </tr>
    <tr>
      <td>max</td>
      <td>99301.000000</td>
      <td>22638.480000</td>
      <td>14.000000</td>
      <td>0.800000</td>
      <td>8399.976000</td>
    </tr>
  </tbody>
</table>
</div>




```python
dataset.shape
```




    (9994, 20)




```python
dataset.size
```




    199880




```python
dataset.ndim
```




    2




```python
dataset.dtypes
```




    Order ID                 object
    Order Date       datetime64[ns]
    Ship Date        datetime64[ns]
    Ship Mode                object
    Customer ID              object
    Customer Name            object
    Segment                  object
    Country                  object
    City                     object
    State                    object
    Postal Code               int64
    Region                   object
    Product ID               object
    Category                 object
    Sub-Category             object
    Product Name             object
    Sales                   float64
    Quantity                  int64
    Discount                float64
    Profit                  float64
    dtype: object



#### To Check If there's duplicate rows or information contained in the dataframe


```python
dataset.duplicated().sum()
```




    1



### Now that it's confirmed that there's duplicate rows in the dataframe and the sum() aggregate function reveals its count to be 1, there's need to call out the exact duplicate(s)


```python
dataset[dataset.duplicated()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>State</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>Row ID</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>3407</td>
      <td>US-2014-150119</td>
      <td>2014-04-23</td>
      <td>2014-04-27</td>
      <td>Standard Class</td>
      <td>LB-16795</td>
      <td>Laurel Beltran</td>
      <td>Home Office</td>
      <td>United States</td>
      <td>Columbus</td>
      <td>Ohio</td>
      <td>43229</td>
      <td>East</td>
      <td>FUR-CH-10002965</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>Global Leather Highback Executive Chair with P...</td>
      <td>281.372</td>
      <td>2</td>
      <td>0.3</td>
      <td>-12.0588</td>
    </tr>
  </tbody>
</table>
</div>



### To further narrow the search down, make the work easier and simplify the task, I used dot index and dot info respectively on the code that revealed the duplicates. This will reveal the info as was revealed by the code. It might not be much but it's to be double sure of the results. And the index of the duplicate row will be known


```python
dataset[dataset.duplicated()].index
```




    Int64Index([3407], dtype='int64', name='Row ID')




```python
dataset[dataset.duplicated()]. info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 1 entries, 3407 to 3407
    Data columns (total 20 columns):
    Order ID         1 non-null object
    Order Date       1 non-null datetime64[ns]
    Ship Date        1 non-null datetime64[ns]
    Ship Mode        1 non-null object
    Customer ID      1 non-null object
    Customer Name    1 non-null object
    Segment          1 non-null object
    Country          1 non-null object
    City             1 non-null object
    State            1 non-null object
    Postal Code      1 non-null int64
    Region           1 non-null object
    Product ID       1 non-null object
    Category         1 non-null object
    Sub-Category     1 non-null object
    Product Name     1 non-null object
    Sales            1 non-null float64
    Quantity         1 non-null int64
    Discount         1 non-null float64
    Profit           1 non-null float64
    dtypes: datetime64[ns](2), float64(3), int64(2), object(13)
    memory usage: 116.0+ bytes


### Then, i thought that if the number revealed as a duplicate row index was correct, the row index from which it was duplicated from will not be far away from that index number. So, i called the index number directly above it alongside the duplicate row index, to compare the information and confirm the duplicate value. The result proved to be true as it revealed my exact assumption


```python
dataset.loc[[3406,3407]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>State</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>Row ID</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>3406</td>
      <td>US-2014-150119</td>
      <td>2014-04-23</td>
      <td>2014-04-27</td>
      <td>Standard Class</td>
      <td>LB-16795</td>
      <td>Laurel Beltran</td>
      <td>Home Office</td>
      <td>United States</td>
      <td>Columbus</td>
      <td>Ohio</td>
      <td>43229</td>
      <td>East</td>
      <td>FUR-CH-10002965</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>Global Leather Highback Executive Chair with P...</td>
      <td>281.372</td>
      <td>2</td>
      <td>0.3</td>
      <td>-12.0588</td>
    </tr>
    <tr>
      <td>3407</td>
      <td>US-2014-150119</td>
      <td>2014-04-23</td>
      <td>2014-04-27</td>
      <td>Standard Class</td>
      <td>LB-16795</td>
      <td>Laurel Beltran</td>
      <td>Home Office</td>
      <td>United States</td>
      <td>Columbus</td>
      <td>Ohio</td>
      <td>43229</td>
      <td>East</td>
      <td>FUR-CH-10002965</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>Global Leather Highback Executive Chair with P...</td>
      <td>281.372</td>
      <td>2</td>
      <td>0.3</td>
      <td>-12.0588</td>
    </tr>
  </tbody>
</table>
</div>



### Now, i can delete whichever of the duplicated values as i deem fit using the drop_duplicates function.


### Then, I'll call the duplicated function to confirm if there's still duplicate values in the dataframe


```python
dataset.drop_duplicates(inplace = True)
dataset.duplicated().sum()
```




    0



### Note that the procedure can also be achieved using the drop function and setting inplace to be True. I run the code below and it worked effectively

### To check for NA values, i use the isna()


```python
dataset.isna().sum()
```




    Order ID         0
    Order Date       0
    Ship Date        0
    Ship Mode        0
    Customer ID      0
    Customer Name    0
    Segment          0
    Country          0
    City             0
    State            0
    Postal Code      0
    Region           0
    Product ID       0
    Category         0
    Sub-Category     0
    Product Name     0
    Sales            0
    Quantity         0
    Discount         0
    Profit           0
    dtype: int64




```python
dataset.notna().sum()
```




    Order ID         9993
    Order Date       9993
    Ship Date        9993
    Ship Mode        9993
    Customer ID      9993
    Customer Name    9993
    Segment          9993
    Country          9993
    City             9993
    State            9993
    Postal Code      9993
    Region           9993
    Product ID       9993
    Category         9993
    Sub-Category     9993
    Product Name     9993
    Sales            9993
    Quantity         9993
    Discount         9993
    Profit           9993
    dtype: int64



### There are no null values in the dataset.


### With my level present level of the dataset, I'll check for the relationship between some of the columns of this dataset, do some grouping on it and start the analysis and visualization steps


```python
dataset.index
```




    Int64Index([   1,    2,    3,    4,    5,    6,    7,    8,    9,   10,
                ...
                9985, 9986, 9987, 9988, 9989, 9990, 9991, 9992, 9993, 9994],
               dtype='int64', name='Row ID', length=9993)



### On Checking the index values, i observed it's been altered as a result of the duplicate value(s) dropped.

### I'll rename the columns to be in an orderly manner and I'll check again


```python
dataset.index = range(1, 9994)
dataset.index
```




    RangeIndex(start=1, stop=9994, step=1)



### The dataset is now ready for further analysis and exploration.

### I rewrite the the completed dataset back to an excel file. Note that this is optional, in case you need the file for use somewhere else

### dataset.to_excel("SSDE.xlsx", index = False)


```python
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>State</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>CA-2016-152156</td>
      <td>2016-11-08</td>
      <td>2016-11-11</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>FUR-BO-10001798</td>
      <td>Furniture</td>
      <td>Bookcases</td>
      <td>Bush Somerset Collection Bookcase</td>
      <td>261.9600</td>
      <td>2</td>
      <td>0.00</td>
      <td>41.9136</td>
    </tr>
    <tr>
      <td>2</td>
      <td>CA-2016-152156</td>
      <td>2016-11-08</td>
      <td>2016-11-11</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>FUR-CH-10000454</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>Hon Deluxe Fabric Upholstered Stacking Chairs,...</td>
      <td>731.9400</td>
      <td>3</td>
      <td>0.00</td>
      <td>219.5820</td>
    </tr>
    <tr>
      <td>3</td>
      <td>CA-2016-138688</td>
      <td>2016-06-12</td>
      <td>2016-06-16</td>
      <td>Second Class</td>
      <td>DV-13045</td>
      <td>Darrin Van Huff</td>
      <td>Corporate</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>California</td>
      <td>90036</td>
      <td>West</td>
      <td>OFF-LA-10000240</td>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>Self-Adhesive Address Labels for Typewriters b...</td>
      <td>14.6200</td>
      <td>2</td>
      <td>0.00</td>
      <td>6.8714</td>
    </tr>
    <tr>
      <td>4</td>
      <td>US-2015-108966</td>
      <td>2015-10-11</td>
      <td>2015-10-18</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>FUR-TA-10000577</td>
      <td>Furniture</td>
      <td>Tables</td>
      <td>Bretford CR4500 Series Slim Rectangular Table</td>
      <td>957.5775</td>
      <td>5</td>
      <td>0.45</td>
      <td>-383.0310</td>
    </tr>
    <tr>
      <td>5</td>
      <td>US-2015-108966</td>
      <td>2015-10-11</td>
      <td>2015-10-18</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>OFF-ST-10000760</td>
      <td>Office Supplies</td>
      <td>Storage</td>
      <td>Eldon Fold 'N Roll Cart System</td>
      <td>22.3680</td>
      <td>2</td>
      <td>0.20</td>
      <td>2.5164</td>
    </tr>
  </tbody>
</table>
</div>



### It's time to start exploring the dataset, deriving insights and plotting visualization.

### What you derive from the datqset depends on your wnd goal, but for learning purpose, let's obtain basic information and plot the visualization where necessary

### Using the unique() on Segment Column revealed that there 3 distinct segment of buyers


```python
dataset["Segment"].unique()
```




    array(['Consumer', 'Corporate', 'Home Office'], dtype=object)



### Using the unique() on Country Column revealed that there's only one distinct country where sales was made.

### There are 4 distinct Regions where sales was made

### There are 49 distinct states where sales was made

### There are 531 distinct cities where sales was made


```python
dataset["Country"].unique()
```




    array(['United States'], dtype=object)




```python
dataset["Region"].unique()
```




    array(['South', 'West', 'Central', 'East'], dtype=object)




```python
pd.value_counts(dataset["State"].unique()).sum()
```




    49




```python
pd.value_counts(dataset["City"].unique()).sum()
```




    531



### The Company has 3 distinct categories of products and

### 17 distinct sub categories of them


```python
dataset["Category"].unique()
```




    array(['Furniture', 'Office Supplies', 'Technology'], dtype=object)




```python
pd.value_counts(dataset["Sub-Category"].unique()).sum()
```




    17



### The company uses 4 distinct means of shipping her products to her customers


```python
pd.value_counts(dataset["Ship Mode"].unique()).sum()
```




    4



### And there are 793 unique customers who made purchase


```python
pd.value_counts(dataset["Customer Name"].unique()).count()
```




    793



### First, let me show all the data we've derived so far in visualization

### To show how many countries the company covered in sales


```python
cov_country = dataset["Sales"].groupby(dataset["Country"])
cov_country1 = cov_country.count()
cov_country1
```




    Country
    United States    9993
    Name: Sales, dtype: int64




```python
label = cov_country1.index
plt.pie(cov_country.unique().count(), labels = label)
plt.ylabel("")
plt.title("Country Representation")
plt.savefig("S-Dset.png")
```

    /data/user/0/ru.iiec.pydroid3/files/arm-linux-androideabi/lib/python3.7/site-packages/ipykernel_launcher.py:2: MatplotlibDeprecationWarning: Non-1D inputs to pie() are currently squeeze()d, but this behavior is deprecated since 3.1 and will be removed in 3.3; pass a 1D array instead.
      



![png](output_52_1.png)


### Now, let me show how many regions are covered in the sales activities


```python
cov_region = dataset["Sales"].groupby(dataset["Region"])
cov_region1 = cov_region.count()
cov_region1
```




    Region
    Central    2323
    East       2847
    South      1620
    West       3203
    Name: Sales, dtype: int64




```python
plt.pie(cov_region1, labels = cov_region1.index,startangle = 60)
plt.title("Region Representation")
plt.savefig("S-Dset1.png")
```


![png](output_55_0.png)


### Now, let me show the states that are covered in the company's sales activities


```python
cov_states = pd.value_counts(dataset.State.unique()).sum()
cov_states
```




    49




```python
print(" The number of states covered in the sales data is",cov_states)
```

     The number of states covered in the sales data is 49


### Now, let me create a representation of the segment of customers who patronize the company or where sales are made to


```python
cov_segment = dataset["Sales"].groupby(dataset["Segment"])
cov_segment1 = cov_segment.count()
cov_segment1
```




    Segment
    Consumer       5191
    Corporate      3020
    Home Office    1782
    Name: Sales, dtype: int64




```python
fig = plt.figure()
axes = fig.add_axes([0,0,1,1])
axes.pie(cov_segment1, labels = cov_segment1.index,startangle = 15)
axes.set_title("Segment of Customers / Sales Category", alpha = 0.85)
fig.savefig("S-Dset3.png")
```


![png](output_61_0.png)


### Now, let me represent the cities covered in sales by this company


```python
cov_cities = pd.value_counts(dataset.City.unique()).sum()
cov_cities
```




    531




```python
print("The number of Cities covered in the sales activities is", cov_cities)
```

    The number of Cities covered in the sales activities is 531


### Now, let me create a visualization of the shipping modes used by the company to deliver products to her customers


```python
ship_mode = pd.value_counts(dataset["Ship Mode"].unique()).sum()
ship_mode
```




    4




```python
shipping_mode = dataset.Sales.groupby(dataset["Ship Mode"])
shipping_mode1 = shipping_mode.count()
shipping_mode1
```




    Ship Mode
    First Class       1538
    Same Day           543
    Second Class      1945
    Standard Class    5967
    Name: Sales, dtype: int64




```python
plt.pie(shipping_mode1, startangle = 140, labels = shipping_mode1.index)
plt.title("Shipping Mode Representation", alpha = 0.85)
```




    Text(0.5, 1.0, 'Shipping Mode Representation')




![png](output_68_1.png)


### Now, I'm going to create a visualization of the company's product categories as well as product sub-categories


```python
products_cat = dataset["Sales"].groupby(dataset["Category"])
products_cat1 = products_cat.count()
products_cat1
```




    Category
    Furniture          2120
    Office Supplies    6026
    Technology         1847
    Name: Sales, dtype: int64




```python
plt.pie(products_cat1, labels = products_cat1.index, startangle = 330)
plt.title("Products Category", alpha = 0.85)
```




    Text(0.5, 1.0, 'Products Category')




![png](output_71_1.png)



```python
products_subcat = dataset["Sales"].groupby(dataset["Sub-Category"])
products_subcat1 = products_subcat.count()
products_subcat11 = products_subcat1.sort_values()
products_subcat11
```




    Sub-Category
    Copiers          68
    Machines        115
    Supplies        190
    Fasteners       217
    Bookcases       228
    Envelopes       254
    Tables          319
    Labels          364
    Appliances      466
    Chairs          616
    Accessories     775
    Art             796
    Storage         846
    Phones          889
    Furnishings     957
    Paper          1370
    Binders        1523
    Name: Sales, dtype: int64




```python
x2 = products_subcat11.index
y2 = products_subcat11.values
plt.barh(x2, y2)
plt.xlabel("Values", alpha = 0.7, fontstyle = 'italic')
plt.ylabel('Sub-Category of Products', alpha = 0.7, fontstyle = 'italic')
plt.title("Products Sub-Category", alpha = 0.85)
```




    Text(0.5, 1.0, 'Products Sub-Category')




![png](output_73_1.png)



```python
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>State</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>CA-2016-152156</td>
      <td>2016-11-08</td>
      <td>2016-11-11</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>FUR-BO-10001798</td>
      <td>Furniture</td>
      <td>Bookcases</td>
      <td>Bush Somerset Collection Bookcase</td>
      <td>261.9600</td>
      <td>2</td>
      <td>0.00</td>
      <td>41.9136</td>
    </tr>
    <tr>
      <td>2</td>
      <td>CA-2016-152156</td>
      <td>2016-11-08</td>
      <td>2016-11-11</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>FUR-CH-10000454</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>Hon Deluxe Fabric Upholstered Stacking Chairs,...</td>
      <td>731.9400</td>
      <td>3</td>
      <td>0.00</td>
      <td>219.5820</td>
    </tr>
    <tr>
      <td>3</td>
      <td>CA-2016-138688</td>
      <td>2016-06-12</td>
      <td>2016-06-16</td>
      <td>Second Class</td>
      <td>DV-13045</td>
      <td>Darrin Van Huff</td>
      <td>Corporate</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>California</td>
      <td>90036</td>
      <td>West</td>
      <td>OFF-LA-10000240</td>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>Self-Adhesive Address Labels for Typewriters b...</td>
      <td>14.6200</td>
      <td>2</td>
      <td>0.00</td>
      <td>6.8714</td>
    </tr>
    <tr>
      <td>4</td>
      <td>US-2015-108966</td>
      <td>2015-10-11</td>
      <td>2015-10-18</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>FUR-TA-10000577</td>
      <td>Furniture</td>
      <td>Tables</td>
      <td>Bretford CR4500 Series Slim Rectangular Table</td>
      <td>957.5775</td>
      <td>5</td>
      <td>0.45</td>
      <td>-383.0310</td>
    </tr>
    <tr>
      <td>5</td>
      <td>US-2015-108966</td>
      <td>2015-10-11</td>
      <td>2015-10-18</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>OFF-ST-10000760</td>
      <td>Office Supplies</td>
      <td>Storage</td>
      <td>Eldon Fold 'N Roll Cart System</td>
      <td>22.3680</td>
      <td>2</td>
      <td>0.20</td>
      <td>2.5164</td>
    </tr>
  </tbody>
</table>
</div>



### To know which category and sub-category of products brought in the highest profit


```python
profit_dist = dataset["Profit"].groupby(dataset["Category"])
profit_dist1 = profit_dist.sum()
profit_dist1
label = profit_dist1.index
explodes = [0,0,0.2]
```


```python
plt.pie(profit_dist1, autopct = "%1.2f%%", startangle = 95, labels = label, explode = explodes)
plt.title("Profit by Product Categories", alpha = 0.8)
plt.savefig("S-Dset10.png")
```


![png](output_77_0.png)



```python
fig = plt.figure()
axes = fig.add_axes([0,0,1,1])
axes.bar(profit_dist1.index, profit_dist1.values)
axes.set_xlabel("Category", alpha = 0.7, fontstyle = "italic")
axes.set_ylabel("Profit Frequency", alpha = 0.7, fontstyle = 'italic')
axes.set_title("Profit by Product Category", alpha = 0.8)
fig.savefig("S-Dset11.png")
```


![png](output_78_0.png)



```python
profits_subcat = dataset['Profit'].groupby(dataset['Sub-Category'])
profits_subcat1 = profits_subcat.sum()
profits_subcat11 = profits_subcat1.sort_values()
profits_subcat11
```




    Sub-Category
    Tables        -17725.4811
    Bookcases      -3472.5560
    Supplies       -1189.0995
    Fasteners        949.5182
    Machines        3384.7569
    Labels          5546.2540
    Art             6527.7870
    Envelopes       6964.1767
    Furnishings    13059.1436
    Appliances     18138.0054
    Storage        21278.8264
    Chairs         26602.2251
    Binders        30221.7633
    Paper          34053.5693
    Accessories    41936.6357
    Phones         44515.7306
    Copiers        55617.8249
    Name: Profit, dtype: float64




```python
profits_subcat11.plot(kind = 'bar')
plt.title('Profit Distribution (Sub-Category)', alpha = 0.8)
plt.xlabel('Sub-Category', alpha = 0.7, fontstyle = 'italic')
plt.ylabel("Profit Frequency", alpha = 0.7, fontstyle = 'italic')
plt.savefig('S-Dset12.png')
```


![png](output_80_0.png)



```python
plt.barh(profits_subcat11.index, profits_subcat11.values)
plt.title('Profit Distribution (Sub-Category)', alpha = 0.8)
plt.ylabel('Sub-Category', alpha = 0.7, fontstyle = 'italic')
plt.xlabel("Profit Frequency", alpha = 0.7, fontstyle = 'italic')
plt.savefig('S-Dset13.png')
```


![png](output_81_0.png)



```python
profit_by_region = dataset['Profit'].groupby(dataset["Region"])
profit_by_region1 = profit_by_region.sum()
profit_by_region11 = profit_by_region1.sort_values()
profit_by_region11
```




    Region
    Central     39706.3625
    South       46749.4303
    East        91534.8388
    West       108418.4489
    Name: Profit, dtype: float64




```python
profit_by_region11.plot(kind = 'bar')
plt.title('Profit Distribution by Regions', alpha = 0.8)
plt.xlabel('Regions', alpha = 0.7, fontstyle = 'italic')
plt.ylabel("Profit Frequency", alpha = 0.7, fontstyle = 'italic')
plt.savefig('S-Dset14.png')
```


![png](output_83_0.png)



```python
profit_by_region11.plot(kind = 'barh')
plt.title('Profit Distribution by Regions', alpha = 0.8)
plt.ylabel('Regions', alpha = 0.7, fontstyle = 'italic')
plt.xlabel("Profit Frequency", alpha = 0.7, fontstyle = 'italic')
plt.savefig('S-Dset15.png')
```


![png](output_84_0.png)



```python
expo = [0,0,0.1,0.1]
labelz = profit_by_region11.index
plt.pie(profit_by_region11, startangle = 105, labels = labelz, explode = expo, autopct = "%1.2f%%")
plt.title("Profit Distribution by Regions", alpha = 0.8)
plt.savefig("S-Dset16.png")
```


![png](output_85_0.png)



```python
dataset.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>State</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>9989</td>
      <td>CA-2014-110422</td>
      <td>2014-01-21</td>
      <td>2014-01-23</td>
      <td>Second Class</td>
      <td>TB-21400</td>
      <td>Tom Boeckenhauer</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Miami</td>
      <td>Florida</td>
      <td>33180</td>
      <td>South</td>
      <td>FUR-FU-10001889</td>
      <td>Furniture</td>
      <td>Furnishings</td>
      <td>Ultra Door Pull Handle</td>
      <td>25.248</td>
      <td>3</td>
      <td>0.2</td>
      <td>4.1028</td>
    </tr>
    <tr>
      <td>9990</td>
      <td>CA-2017-121258</td>
      <td>2017-02-26</td>
      <td>2017-03-03</td>
      <td>Standard Class</td>
      <td>DB-13060</td>
      <td>Dave Brooks</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Costa Mesa</td>
      <td>California</td>
      <td>92627</td>
      <td>West</td>
      <td>FUR-FU-10000747</td>
      <td>Furniture</td>
      <td>Furnishings</td>
      <td>Tenex B1-RE Series Chair Mats for Low Pile Car...</td>
      <td>91.960</td>
      <td>2</td>
      <td>0.0</td>
      <td>15.6332</td>
    </tr>
    <tr>
      <td>9991</td>
      <td>CA-2017-121258</td>
      <td>2017-02-26</td>
      <td>2017-03-03</td>
      <td>Standard Class</td>
      <td>DB-13060</td>
      <td>Dave Brooks</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Costa Mesa</td>
      <td>California</td>
      <td>92627</td>
      <td>West</td>
      <td>TEC-PH-10003645</td>
      <td>Technology</td>
      <td>Phones</td>
      <td>Aastra 57i VoIP phone</td>
      <td>258.576</td>
      <td>2</td>
      <td>0.2</td>
      <td>19.3932</td>
    </tr>
    <tr>
      <td>9992</td>
      <td>CA-2017-121258</td>
      <td>2017-02-26</td>
      <td>2017-03-03</td>
      <td>Standard Class</td>
      <td>DB-13060</td>
      <td>Dave Brooks</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Costa Mesa</td>
      <td>California</td>
      <td>92627</td>
      <td>West</td>
      <td>OFF-PA-10004041</td>
      <td>Office Supplies</td>
      <td>Paper</td>
      <td>It's Hot Message Books with Stickers, 2 3/4" x 5"</td>
      <td>29.600</td>
      <td>4</td>
      <td>0.0</td>
      <td>13.3200</td>
    </tr>
    <tr>
      <td>9993</td>
      <td>CA-2017-119914</td>
      <td>2017-05-04</td>
      <td>2017-05-09</td>
      <td>Second Class</td>
      <td>CC-12220</td>
      <td>Chris Cortes</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Westminster</td>
      <td>California</td>
      <td>92683</td>
      <td>West</td>
      <td>OFF-AP-10002684</td>
      <td>Office Supplies</td>
      <td>Appliances</td>
      <td>Acco 7-Outlet Masterpiece Power Center, Wihtou...</td>
      <td>243.160</td>
      <td>2</td>
      <td>0.0</td>
      <td>72.9480</td>
    </tr>
  </tbody>
</table>
</div>




```python
profits_by_state = dataset["Profit"].groupby(dataset["State"])
profits_by_state1 = profits_by_state.sum()
profits_by_state11 = profits_by_state1.sort_values()
profits_by_state11
```




    State
    Texas                  -25729.3563
    Ohio                   -16959.3178
    Pennsylvania           -15559.9603
    Illinois               -12607.8870
    North Carolina          -7490.9122
    Colorado                -6527.8579
    Tennessee               -5341.6936
    Arizona                 -3427.9246
    Florida                 -3399.3017
    Oregon                  -1190.4705
    Wyoming                   100.1960
    West Virginia             185.9216
    North Dakota              230.1497
    South Dakota              394.8283
    Maine                     454.4862
    Idaho                     826.7231
    Kansas                    836.4435
    District of Columbia     1059.5893
    New Mexico               1157.1161
    Iowa                     1183.8119
    New Hampshire            1706.5028
    South Carolina           1769.0566
    Montana                  1833.3285
    Nebraska                 2037.0942
    Louisiana                2196.1023
    Vermont                  2244.9783
    Utah                     2546.5335
    Mississippi              3172.9762
    Nevada                   3316.7659
    Connecticut              3511.4918
    Arkansas                 4008.6871
    Oklahoma                 4853.9560
    Alabama                  5786.8253
    Missouri                 6436.2105
    Massachusetts            6785.5016
    Maryland                 7031.1788
    Rhode Island             7285.6293
    Wisconsin                8401.8004
    New Jersey               9772.9138
    Delaware                 9977.3748
    Minnesota               10823.1874
    Kentucky                11199.6966
    Georgia                 16250.0433
    Indiana                 18382.9363
    Virginia                18597.9504
    Michigan                24463.1876
    Washington              33402.6517
    New York                74038.5486
    California              76381.3871
    Name: Profit, dtype: float64




```python
profits_by_state11.plot(kind = 'barh', color = 'k', figsize = (6,15))
plt.title('Profit Distribution by States', alpha = 0.8)
plt.xlabel('States', alpha = 0.7, fontstyle = 'italic')
plt.ylabel("Profit Frequency", alpha = 0.7, fontstyle = 'italic')
plt.savefig('S-Dset17.png')
```


![png](output_88_0.png)



```python
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Ship Date</th>
      <th>Ship Mode</th>
      <th>Customer ID</th>
      <th>Customer Name</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>State</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Product Name</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>CA-2016-152156</td>
      <td>2016-11-08</td>
      <td>2016-11-11</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>FUR-BO-10001798</td>
      <td>Furniture</td>
      <td>Bookcases</td>
      <td>Bush Somerset Collection Bookcase</td>
      <td>261.9600</td>
      <td>2</td>
      <td>0.00</td>
      <td>41.9136</td>
    </tr>
    <tr>
      <td>2</td>
      <td>CA-2016-152156</td>
      <td>2016-11-08</td>
      <td>2016-11-11</td>
      <td>Second Class</td>
      <td>CG-12520</td>
      <td>Claire Gute</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>FUR-CH-10000454</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>Hon Deluxe Fabric Upholstered Stacking Chairs,...</td>
      <td>731.9400</td>
      <td>3</td>
      <td>0.00</td>
      <td>219.5820</td>
    </tr>
    <tr>
      <td>3</td>
      <td>CA-2016-138688</td>
      <td>2016-06-12</td>
      <td>2016-06-16</td>
      <td>Second Class</td>
      <td>DV-13045</td>
      <td>Darrin Van Huff</td>
      <td>Corporate</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>California</td>
      <td>90036</td>
      <td>West</td>
      <td>OFF-LA-10000240</td>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>Self-Adhesive Address Labels for Typewriters b...</td>
      <td>14.6200</td>
      <td>2</td>
      <td>0.00</td>
      <td>6.8714</td>
    </tr>
    <tr>
      <td>4</td>
      <td>US-2015-108966</td>
      <td>2015-10-11</td>
      <td>2015-10-18</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>FUR-TA-10000577</td>
      <td>Furniture</td>
      <td>Tables</td>
      <td>Bretford CR4500 Series Slim Rectangular Table</td>
      <td>957.5775</td>
      <td>5</td>
      <td>0.45</td>
      <td>-383.0310</td>
    </tr>
    <tr>
      <td>5</td>
      <td>US-2015-108966</td>
      <td>2015-10-11</td>
      <td>2015-10-18</td>
      <td>Standard Class</td>
      <td>SO-20335</td>
      <td>Sean O'Donnell</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>OFF-ST-10000760</td>
      <td>Office Supplies</td>
      <td>Storage</td>
      <td>Eldon Fold 'N Roll Cart System</td>
      <td>22.3680</td>
      <td>2</td>
      <td>0.20</td>
      <td>2.5164</td>
    </tr>
  </tbody>
</table>
</div>




```python
seg_ship = dataset.Sales.groupby([dataset.Segment, dataset["Ship Mode"]])
seg_ship1 = seg_ship.count().sort_values()
seg_ship1
```




    Segment      Ship Mode     
    Home Office  Same Day           112
    Corporate    Same Day           114
    Home Office  First Class        284
                 Second Class       316
    Consumer     Same Day           317
    Corporate    First Class        485
                 Second Class       609
    Consumer     First Class        769
                 Second Class      1020
    Home Office  Standard Class    1070
    Corporate    Standard Class    1812
    Consumer     Standard Class    3085
    Name: Sales, dtype: int64




```python
seg_ship1.plot(kind = "barh", figsize = (6,15))
```




    <matplotlib.axes._subplots.AxesSubplot at 0xa1dcc770>




![png](output_91_1.png)



```python
subcat_ship = dataset["Sales"].groupby([dataset["Sub-Category"], dataset["Ship Mode"]])
subcat_ship1 = subcat_ship.count()
subcat_ship1
```




    Sub-Category  Ship Mode     
    Accessories   First Class       128
                  Same Day           41
                  Second Class      162
                  Standard Class    444
    Appliances    First Class        76
                                   ... 
    Supplies      Standard Class    111
    Tables        First Class        47
                  Same Day           21
                  Second Class       61
                  Standard Class    190
    Name: Sales, Length: 68, dtype: int64



### Now, let's try some other visualization.

### You'll extract Sales across various Regions and States of the United States

### Note that these exercise are just for your practice sake. The sales is made over a period of years. There result obtained is the sales over time. To obtain that of specific periods will require different approach.

### The info extracted below is the overall sales over a period of time


```python
newset = dataset.Sales.groupby([dataset.Region, dataset.State])
newset1 = newset.sum()
newset1.head(15)
```




    Region   State       
    Central  Illinois         80166.1010
             Indiana          53555.3600
             Iowa              4579.7600
             Kansas            2914.3100
             Michigan         76269.6140
             Minnesota        29863.1500
             Missouri         22205.1500
             Nebraska          7464.9300
             North Dakota       919.9100
             Oklahoma         19683.3900
             South Dakota      1315.5600
             Texas           170188.0458
             Wisconsin        32114.6100
    East     Connecticut      13384.3570
             Delaware         27451.0690
    Name: Sales, dtype: float64




```python
newset11 = newset1.unstack(0)
newset11.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Region</th>
      <th>Central</th>
      <th>East</th>
      <th>South</th>
      <th>West</th>
    </tr>
    <tr>
      <th>State</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Alabama</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>19510.640</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Arizona</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>35282.0010</td>
    </tr>
    <tr>
      <td>Arkansas</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>11678.130</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>California</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>457687.6315</td>
    </tr>
    <tr>
      <td>Colorado</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>32108.1180</td>
    </tr>
    <tr>
      <td>Connecticut</td>
      <td>NaN</td>
      <td>13384.357</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Delaware</td>
      <td>NaN</td>
      <td>27451.069</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>District of Columbia</td>
      <td>NaN</td>
      <td>2865.020</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Florida</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>89473.708</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Georgia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>49095.840</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Idaho</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4382.4860</td>
    </tr>
    <tr>
      <td>Illinois</td>
      <td>80166.101</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Indiana</td>
      <td>53555.360</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Iowa</td>
      <td>4579.760</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Kansas</td>
      <td>2914.310</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Kentucky</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>36591.750</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Louisiana</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9217.030</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Maine</td>
      <td>NaN</td>
      <td>1270.530</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Maryland</td>
      <td>NaN</td>
      <td>23705.523</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Massachusetts</td>
      <td>NaN</td>
      <td>28634.434</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



### The Sales made in the states under the Central Region is extracted below


```python
cent_states = newset11.Central[newset11.Central > 0]
cent_states
```




    State
    Illinois         80166.1010
    Indiana          53555.3600
    Iowa              4579.7600
    Kansas            2914.3100
    Michigan         76269.6140
    Minnesota        29863.1500
    Missouri         22205.1500
    Nebraska          7464.9300
    North Dakota       919.9100
    Oklahoma         19683.3900
    South Dakota      1315.5600
    Texas           170188.0458
    Wisconsin        32114.6100
    Name: Central, dtype: float64




```python
sorted = cent_states.sort_values()
sorted.plot.barh()
plt.title("Sales in the Central Region States", alpha = 0.85)
plt.xlabel("Sales Frequency", alpha = 0.7, fontstyle = 'italic')
plt.ylabel("States of The Central Region", alpha = 0.7, fontstyle = "italic")
plt.savefig("S-Dset39.png")
```


![png](output_99_0.png)


### The Sales made in the states under the Eastern Region is extracted below 


```python
east_states = newset11.East[newset11.East > 0]
east_states
```




    State
    Connecticut              13384.357
    Delaware                 27451.069
    District of Columbia      2865.020
    Maine                     1270.530
    Maryland                 23705.523
    Massachusetts            28634.434
    New Hampshire             7292.524
    New Jersey               35764.312
    New York                310876.271
    Ohio                     77976.764
    Pennsylvania            116511.914
    Rhode Island             22627.956
    Vermont                   8929.370
    West Virginia             1209.824
    Name: East, dtype: float64




```python
east_sorted = east_states.sort_values()
east_sorted.plot.barh()
plt.title("Sales in the Eastern Region States", alpha = 0.85)
plt.xlabel("Sales Frequency", alpha = 0.7, fontstyle = 'italic')
plt.ylabel("States of The Eastern Region", alpha = 0.7, fontstyle = "italic")
plt.savefig("S-Dset40.png")
```


![png](output_102_0.png)


### The Sales made in the states under the Southern Region is extracted below


```python
south_states = newset11.South[newset11.South > 0]
south_states
```




    State
    Alabama           19510.640
    Arkansas          11678.130
    Florida           89473.708
    Georgia           49095.840
    Kentucky          36591.750
    Louisiana          9217.030
    Mississippi       10771.340
    North Carolina    55603.164
    South Carolina     8481.710
    Tennessee         30661.873
    Virginia          70636.720
    Name: South, dtype: float64




```python
sorted_south = south_states.sort_values()
sorted_south.plot.barh()
plt.title("Sales in the Southern Region States", alpha = 0.85)
plt.xlabel("Sales Frequency", alpha = 0.7, fontstyle = 'italic')
plt.ylabel("States of The Southern Region", alpha = 0.7, fontstyle = "italic")
plt.savefig("S-Dset41.png")
```


![png](output_105_0.png)


### The Sales made in the states under the Western Region is extracted below


```python
west_states = newset11.West[newset11.West > 0]
west_states
```




    State
    Arizona        35282.0010
    California    457687.6315
    Colorado       32108.1180
    Idaho           4382.4860
    Montana         5589.3520
    Nevada         16729.1020
    New Mexico      4783.5220
    Oregon         17431.1500
    Utah           11220.0560
    Washington    138641.2700
    Wyoming         1603.1360
    Name: West, dtype: float64




```python
sorted_west = west_states.sort_values()
sorted_west.plot.barh()
plt.title("Sales in the Western Region States", alpha = 0.85)
plt.xlabel("Sales Frequency", alpha = 0.7, fontstyle = 'italic')
plt.ylabel("States of The Western Region", alpha = 0.7, fontstyle = "italic")
plt.savefig("S-Dset42.png")
```


![png](output_108_0.png)


### Here comes to the end of another lesson using all the amazing libraries. And i must say it again that I'm excited at the possibilities one can achieve using the Python Data Science libraries.

### The best way to learn is by doing,bdo get your hands into action.

# Practice! Practice!! Practice!!!

### And I urge you, once again, to feel encouraged by what you're doing. It'll get better and come naturally as you get more committed to the process

### Happy Learning !


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
